/* global web */

function submitMethod(){
    if ($("#form_new_method #input_title").val()==""){
        web.mostrar_error("you have to specify a name for the method");
        return;
    }
    if ($("#form_new_method #inp_file_1").val()==""){
        web.mostrar_error("you have to select a file to upload");
        return;
    }
    
    if($("#form_new_method #inp_file_1")[0].files==undefined){
        web.mostrar_error("You need a navigator that supports Standards. Use preferently Chrome or Firefox.");
        return;
    }
    
    var currentFilesize = $("#form_new_method #inp_file_1")[0].files[0].size;
    var maxMB = 300;
    if(currentFilesize > 1024*1024*maxMB ){
        web.mostrar_error("The maximum file size allowed to upload is: <b>" + maxMB + "MB</b>. (your file: <b>" + Math.round(currentFilesize/(1024*1024)) + "MB</b>) If you need to submit a file larger than " + maxMB + "MB, please contact us through rrc@cvc.uab.es");
        return;
    }
    
    var xhr2 = !! ( window.FormData && ("upload" in ($.ajaxSettings.xhr()) ) );
    if(!xhr2){
        web.mostrar_error("You need a navigator that supports Standards. Use preferently Chrome or Firefox.");
        return;
    }
    //$("#modal_submit_new").find("#form_new_method").submit();
    
    var formData = new FormData($("#form_new_method")[0]);
    var req = new XMLHttpRequest();
    req.upload.addEventListener("progress", function(evt){
        if (evt.lengthComputable) {
              var percentComplete = evt.loaded / evt.total;
              web.wait_screen("Uploading.. " + Math.round(percentComplete*1000)/10 + "%");
        } else {
            web.wait_screen("Uploading.. ");
        }
    }, false);    
    req.addEventListener("progress", function(evt){
        if (evt.lengthComputable) {
              var percentComplete = evt.loaded / evt.total;
              web.wait_screen("Validating.. " + Math.round(percentComplete*1000)/10 + "%");
        } else {
            web.wait_screen("Validating.. ");
        }        
    }, false);
    req.open('POST', '?com=evaluation&action=user_submit_method&validation=' + web.is_validtaion);
    req.onreadystatechange = function (aEvt) {
      if (req.readyState == 4) {
         if(req.status == 200){
                try {
                    var result = JSON.parse(req.responseText);
                    if (result.resultat){
                         document.location.reload();
                    }else{
                        web.mostrar_error(result.descripcio);
                    }                
                } catch(e) {
                    web.mostrar_error("Error uploading the file. Error:" + e); // error in the above string (in this case, yes)!
                }
            }else{
                web.mostrar_error("Error uploading the file. Invalid server response:" + req.status);
        }
          
      }
    };
    web.wait_screen("Please wait, your results are being uploaded and validated..");
    req.send(formData);    
}

function see_submit(validation){
    web.is_validtaion = validation;
    
    var dades = {"challenge":web.getParametre("ch"),"task":web.getParametre("task")};
    web.mostrar_modal_post("?com=mymethods&action=modal_new_method",dades,"modal_submit_new",true,function(){
        
        var $dialog = $("#modal_submit_new");
        $dialog.find("div.instructions").css("display",(validation=="1"?"none":"block"));
        
        /*$dialog.find("#form_new_method").submit(function() {
               web.wait_screen("Please wait, your results are being uploaded and validated..");
               var options = {
               url : '?com=evaluation&action=user_submit_method&validation=' + validation ,
               dataType: 'json',
               success : function(result){
                   if (result.resultat){
                        document.location.reload();
                   }else{
                       web.mostrar_error(result.descripcio);
                   }
               },
               error : function(){
                   web.mostrar_error("Error on server");
               }
               };
               $(this).ajaxSubmit(options);
               return false;
            });*/
       
    });
    /*
    $("#div_form_results_" + task).dialog({
        dialogClass: 'submit',
        title: 'Submit new method',
        width: 800,
        buttons: {
            "Submit": function () {
                if ($("#form_results_" + task + " #inp_title").val()==""){
                    web.mostrar_error("you have to specify a name for the method");
                    return;
                }
                if ($("#form_results_" + task + " #inp_file").val()==""){
                    web.mostrar_error("you have to select a file to upload");
                    return;
                }
                $("#form_results_" + task).submit();
            },
            Cancel: function () {
                $(this).dialog("close");
            }
        },
        open: function () {
            $("#form_results_" + task + " #inp_title").val("");
            $("#form_results_" + task + " #inp_file").val("");
            $(this).parent().find('.ui-dialog-buttonpane button').eq(0).removeClass('ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only').addClass('botoVerd');
            $(this).parent().find('.ui-dialog-buttonpane button').eq(1).removeClass('ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only').addClass('botoGris');            
            $(this).find("div.instructions").css("display",(validation=="1"?"none":"block"));
        },
        close: function () {
            // Close code here (incidentally, same as Cancel code)
        }
    });*/
}
function see_instructions(task,validation){
    web.current_task = task;
    web.is_validtaion = validation;
    $("#div_form_instructions_" + task).dialog({
        dialogClass: 'submit',
        title: 'Submit new method',
        width: 800,
        buttons: {
            Cancel: function () {
                $(this).dialog("close");
            }
        },
        open: function () {
            $(this).parent().find('.ui-dialog-buttonpane button').eq(0).removeClass('ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only').addClass('botoGris');            
        },
        close: function () {
            // Close code here (incidentally, same as Cancel code)
        }
    });
}

$(document).ready(function(){


     $("span.log").mouseenter(function(){
         $(this).find("span.log_info").css("display","block");
     }).mouseleave(function(){$("span.log_info").css("display","none");});
});

function edit_method(id_s,grid){
    
    var url = "?com=evaluation&action=form_method";
    var dades = {"id_submit":id_s};
    web.mostrar_modal_post(url,dades,'modal_edit_method',true,function(){
        var $modal = $("#modal_edit_method");
        $modal.find('[data-toggle="tooltip"]').tooltip();  
        
        $modal.find('.btn.save').click(function(){
            var url = "?com=evaluation&action=update_method";
            var data = $("#form_method_data").serialize();
            var msg = "Please wait..";
            web.pantalla_espera(msg);
            $.post(url,data,function(result){
                if (!result.resultat){
                    web.mostrar_error(result.descripcio);
                }else{
                    web.tancar_pantalla_espera();
                    $modal.modal("hide");
                    if(grid!=undefined && grid!=null){
                        $(grid).trigger("reloadGrid");
                    }else{
                        location.reload();
                    }
                }
            },"json");    
        });
    });
}

function delete_method(submit,grid){
    $('#div_delete_submit').remove();
    
    var message = submit=="0" ?  "Are you sure to delete all selected methods?" : "Are you sure to delete this method?";
    $("<div id='div_delete_submit'></div>").html(message).dialog({
        title: 'Confirm',
        buttons: {
            "Ok": function () {
                var dialog = this;
                web.pantalla_espera();
                var url = "?com=evaluation&action=delete_submit";
                var dades = {"id_submit":submit};
                if(submit=="0" && grid != undefined){
                   dades = {"ids" : $(grid).jqGrid('getGridParam','selarrrow')};
                }                
                $.post(url, dades, function (result) {
                    if (result.resultat) {
                        web.tancar_pantalla_espera();
                        $(dialog).dialog("close");
                        if (grid != undefined){
                            $(grid).trigger("reloadGrid");
                        }else{
                            document.location.reload();
                        }
                    } else {
                        web.mostrar_error(result.descripcio);
                    }
                }, "json");
            },
            Cancel: function () {
                $(this).dialog("close");
            }
        },
        open: function () {
            $(this).parent().find('.ui-dialog-buttonpane button').eq(0).removeClass('ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only').addClass('botoVerd');
            $(this).parent().find('.ui-dialog-buttonpane button').eq(1).removeClass('ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only').addClass('botoGris');            
        },
        close: function () {
            // Close code here (incidentally, same as Cancel code)
        }
    });

}
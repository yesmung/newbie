/* global google, CKEDITOR */

var ClassWeb = function(){
    this.url_servidor = document.location.protocol + "//" + document.location.host;
};
var web = new ClassWeb();


ClassWeb.prototype.wait_screen = function(msg){
    if(this.dialog==undefined){
        web.dialog = $(
                    '<div class="modal_espera modal fade" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-hidden="true" style="padding-top:15%; overflow-y:visible;">' +
                    '<div class="modal-dialog modal-m">' +
                    '<div class="modal-content"></div></div></div>');    
    }

    web.dialog.find('.modal-content').html(
                    '<div class="modal-header"><h3 style="margin:0;"></h3></div>' +
                    '<div class="modal-body">' +
                            '<div class="progress progress-striped active" style="margin-bottom:0;"><div class="progress-bar" style="width: 100%"></div></div>' +
                    '</div>');    
    
    web.dialog.find('h3').text(msg);
    web.dialog.modal();    
};

ClassWeb.prototype.close_overlay = function(){
    web.dialog.modal('hide');
};
ClassWeb.prototype.close_wait_screen = function(){
    web.dialog.modal('hide');
};

ClassWeb.prototype.show_error = function(msg){
    if(this.dialog==undefined){
        web.dialog = $(
                    '<div class="modal_espera modal fade" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-hidden="true" style="padding-top:15%; overflow-y:visible;">' +
                    '<div class="modal-dialog modal-m">' +
                    '<div class="modal-content"></div></div></div>');    
    }
    
    web.dialog.find('.modal-content').html(
                    '<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button><h3 style="margin:0;">Error</h3></div>' +
                    '<div class="modal-body"><div class="alert alert-danger" role="alert">'
                             + msg +
                    '</div></div>' +
            '<div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal">Close</button></div>');    
    
    //web.dialog.find('h3').text(msg);
    web.dialog.modal();
};

ClassWeb.prototype.show_info= function(msg){
    if(this.dialog==undefined){
        web.dialog = $(
                    '<div class="modal_espera modal fade" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-hidden="true" style="padding-top:15%; overflow-y:visible;">' +
                    '<div class="modal-dialog modal-m">' +
                    '<div class="modal-content"></div></div></div>');    
    }
    
    web.dialog.find('.modal-content').html(
                    '<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button><h3 style="margin:0;">Error</h3></div>' +
                    '<div class="modal-body"><div class="alert alert-info" role="alert">'
                             + msg +
                    '</div></div>' +
            '<div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal">Close</button></div>');    
    
    //web.dialog.find('h3').text(msg);
    web.dialog.modal();
};


ClassWeb.prototype.mostrar_error = function(msg,titol){
    web.show_error(msg);
};
ClassWeb.prototype.pantalla_espera = function(msg){
    web.wait_screen(msg);
};

ClassWeb.prototype.tancar_pantalla_espera = function(){
    web.close_overlay();
};

ClassWeb.prototype.login = function(){
    var url = "?com=contestant&action=login";
    var dades = $("#form_login").serialize();
    $.post(url,dades,function(resultat){
        if (resultat.resultat){
            location.reload();
        }else{
            $("#span_espera").html(resultat.descripcio);
        }
    },"json");
};
ClassWeb.prototype.logout = function(){
    var url = "?com=contestant&action=logout";
    $.post(url,function(resultat){
        if (resultat.resultat){
            location.reload();
        }
    },"json");
};

$.ajaxSetup({
    error: function(event, jqXHR, ajaxSettings, thrownError) {
        var msg = event.status==200? "Not valid response" : "Response error";
        web.mostrar_error(msg);
        console.log("Status:" + event.status + " " + event.statusText);
        console.log("thrownError:" + thrownError);
    }
});

$(window).resize(function (event) {
    $('.ui-dialog').position({my: 'center',
                  at: 'center',
                  of: window,
                  collision: 'fit'});
});


function new_user(){
    var data = $("#form_new_user").serialize();
    var url = "?com=contestant&action=new_user";
    $.post(url,data,function(result){
        if (!result.resultat){
            web.mostrar_error(result.descripcio);
        }else{
            location.href="?com=contestant&view=after_new&email=" + $("#input_email").val();
        }
    },"json");
}

ClassWeb.prototype.restore_password = function(){
    var data = $("#form_password").serialize();
    var url = "?com=contestant&action=restore";
    $("#span_msg_registered").text("validating..").removeClass("green").removeClass("red");
    $.post(url,data,function(result){
        if (!result.resultat){
            $("#span_msg_registered").text(result.descripcio).removeClass("green").addClass("red");
        }else{
            
            $("#span_msg_registered").text("We have sent an e-mail with the instructions to change your password").removeClass("red").addClass("green");
            
            
        }
    },"json");
};
ClassWeb.prototype.change_password = function(){
    var data = $("#form_canvi_p").serialize();
    var url = "?com=contestant&action=change_password";
    $("#span_msg_password").text("changing..").removeClass("green,red");
    $.post(url,data,function(result){
        if (!result.resultat){
            $("#span_msg_password").text(result.descripcio).removeClass("green").addClass("red");
        }else{
            $("#span_msg_password").text("Your password have been changed succesfully").removeClass("red").addClass("green");

        }
    },"json");
};

jQuery.cachedScript = function( url, options ) {
 
  // Allow user to set any option except for dataType, cache, and url
  options = $.extend( options || {}, {
    dataType: "script",
    cache: false,
    url: url
  });
 
  // Use $.ajax() since it is more flexible than $.getScript
  // Return the jqXHR object so we can chain callbacks
  return jQuery.ajax( options );
};

ClassWeb.prototype.carregar_api_grafics = function(callback){
      google.load('visualization', '1',
      {packages:['corechart'],callback:callback});
};
ClassWeb.prototype.carregar_api_grafics_geo = function(callback){
      google.charts.load('visualization', '1',
      {packages:['corechart','geochart'],mapsApiKey:'AIzaSyCzl7deyiw1dKA3brM72kVjF4mlo567Nc4',callback:callback});
};


ClassWeb.prototype.carregar_ckeditor = function(callback){
    if(web.ckeditorCarregat){
        callback();
    }else{
        CKEDITOR_BASEPATH = web.url_servidor + "/js/ckeditor_4_6_2/";
        $.cachedScript( web.url_servidor + "/js/ckeditor_4_6_2/ckeditor.js").done(function( script, textStatus ) {
            CKEDITOR.timestamp='XX14';
            $.cachedScript( web.url_servidor + "/js/ckeditor_4_6_2/adapters/jquery.js").done(function( script, textStatus ) {
                web.ckeditorCarregat = true;
                callback();
            });        
        });
    }
};

$.widget("ui.dialog", $.ui.dialog, {
    _allowInteraction: function(event) {
        return !!$(event.target).closest(".cke_dialog").length || this._super(event);
    }
});

function show_terms(){
    $("#div_terms").css("display","block");
}


function footer_location(){
    if(!$("footer").length){
        return;
    }
    var tamany_contingut = $("main").outerHeight() + $("header").outerHeight();
    var tamany_peu = $("footer").outerHeight();

    if ((tamany_contingut+tamany_peu)< $(window).height()  ){
        //$("main").css("minHeight",  ($(window).height() - $("header").outerHeight() -tamany_peu-40) + "px"   );
        
        //$("footer").css({
        //    "display":"block","position":"fixed","bottom":"0px","right":"0px","left":"0px"
        //});
    }else{
        //$("footer").css({
        //    "display":"block","position":"static","bottom":"auto","right":"auto","left":"auto"
        //});
    }
};

var getUrlParameter = function getUrlParameter(sParam) {
    var sPageURL = decodeURIComponent(window.location.search.substring(1)),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : sParameterName[1];
        }
    }
};

ClassWeb.prototype.mostrar_modal = function(url,id,large,callback){
    return web.mostrar_modal_post(url,{},id,large,callback);
};

ClassWeb.prototype.mostrar_modal_post = function(url,dades,id,large,callback){
    if (id==undefined){
        id = uniqId();
    }else if (id==""){
        id = uniqId();
    }
    if(large==undefined){
        large=false;
    }
    if(!$("#" + id).length){
        $("body").append(web.html_modal(id,large));
    }
    
    //carregar url
    $.post(url,dades,function(data){
        $("#" + id).find(".modal-content").html(data).data('url',url);
        $("#" + id).find('[data-toggle="tooltip"]').tooltip();
        if(callback!=undefined){
            callback();
        }        
                
        $("#" + id).modal({
        backdrop: 'static',
        keyboard: false}).on('hidden.bs.modal', function() {
            $(this).remove();
        });  
    });
    return id;
};
ClassWeb.prototype.mostrar_modal_html = function(title,html,html_footer,id,large,callback){
    if (id==undefined){
        id = uniqId();
    }else if (id==""){
        id = uniqId();
    }
    if(large==undefined){
        large=false;
    }
    if(!$("#" + id).length){
        $("body").append(web.html_modal_content(id,large,title,html,html_footer));
    }
    
    $("#" + id).find('[data-toggle="tooltip"]').tooltip();
    if(callback!=undefined){
        callback();
    }        
    $("#" + id).modal().on('hidden.bs.modal', function() {
        $(this).remove();
    });  

    return id;
};

ClassWeb.prototype.html_modal = function(id,large){
    return "<div class='modal fade' id='" + id + "' tabindex='-1' role='dialog' aria-labelledby='" + id + "' aria-hidden='true'>" + 
        '<div class="modal-dialog' + (large? " modal-lg" : "") + '">'+
            '<div class="modal-content">' +
        '</div>'+
      '</div>'+
    '</div>';
};

ClassWeb.prototype.html_modal_content = function(id,large,title,html,html_footer){
    var html = "<div class='modal fade' id='" + id + "' tabindex='-1' role='dialog' aria-labelledby='" + id + "' aria-hidden='true'>" + 
        '<div class="modal-dialog' + (large? " modal-lg" : "") + '">'+
            '<div class="modal-content">' +
            "<div class='modal-header'>" +
        "<button type='button' class='close' data-dismiss='modal' aria-hidden='true'>&times;</button>" +
        "<h4 class='modal-title' id='myModalLabel'>" + title + "</h4>" +
    "</div>" +
    "<div class='modal-body'>" + html + "</div>";
     
     if(html_footer!=""){
        html += "<div class='modal-footer'>" + html_footer + "</div>";
    }
    html += '</div>'+
      '</div>'+
    '</div>';    
    return html;
};

function copy(element) {
  var $temp = $("<input>");
  $("body").append($temp);
  $temp.val($(element).text()).select();
  document.execCommand("copy");
  $temp.remove();
  web.mostrar_modal_html("Action","The text is copied to the clipboard","<button class='btn btn-success' data-dismiss='modal'>Done</button>");
}

function uniqId() {
    var id = Math.round(new Date().getTime() + (Math.random() * 100));
    while($("#" + id).length){
        id = Math.round(new Date().getTime() + (Math.random() * 100));
    }
    return id;
}

ClassWeb.prototype.recarregar_modal = function(id){
    var url = $("#" + id).data('url');
    $.post(url,function(data){
        $("#" + id).find(".modal-content").html(data);
    });
        
};


$(document).ready(function(){
    $(document).on('show.bs.modal', '.modal', function () {
        var zIndex = 1040 + (10 * $('.modal:visible').length);
        $(this).css('z-index', zIndex);
        setTimeout(function() {
            $('.modal-backdrop').not('.modal-stack').css('z-index', zIndex - 1).addClass('modal-stack');
        }, 0);
    });
    
    $(document).on('hidden.bs.modal', '.modal', function () {
        if($('.modal:visible').length){
            $("body").addClass("modal-open");
        }
    });

});
/*
$.fn.modal.Constructor.prototype.enforceFocus = function() {
    $( document )
        .off( 'focusin.bs.modal' ) // guard against infinite focus loop
        .on( 'focusin.bs.modal', $.proxy( function( e ) {
            if (
                this.$element[ 0 ] !== e.target && !this.$element.has( e.target ).length
                // CKEditor compatibility fix start.
                && !$( e.target ).closest( '.cke_dialog, .cke' ).length
                // CKEditor compatibility fix end.
            ) {
                this.$element.trigger( 'focus' );
            }
        }, this ) );
};
*/

ClassWeb.prototype.getParametre = function(nomP){
    var $_GET = {};
    document.location.search.replace(/\??(?:([^=]+)=([^&]*)&?)/g, function () {
        function decode(s) {
            return decodeURIComponent(s.split("+").join(" "));
        }
        $_GET[decode(arguments[1])] = decode(arguments[2]);
    });
    return $_GET[nomP];
};
$.extend($.ui.dialog.prototype.options, {
    resizable: false,
    draggable: false,
    modal: true,
    postition:'center',
    show: {
      effect: "slide",
      duration: 500
    },    
    hide: {
      effect: "drop",
      duration: 500
    }

});

